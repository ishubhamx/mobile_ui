import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";

@Injectable({
  providedIn: "root"
})
export class UtilityService {
  private searchSource = new BehaviorSubject(true);
  currentSearchState = this.searchSource.asObservable();

  private loaderSource = new BehaviorSubject(true);
  currentLoaderState = this.loaderSource.asObservable();

  constructor() {}

  isLoaderVisible = true;
  isSearchVisible = true;
  toggleSearch() {}
  hideSearch() {
    this.searchSource.next(false);
    this.isSearchVisible = false;
  }
  showSearch() {
    this.isSearchVisible = true;
    this.searchSource.next(true);
  }
  toggleLoader() {
    this.loaderSource.next((this.isLoaderVisible = !this.isLoaderVisible));
  }
}
