import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cashback-by-sites-item',
  templateUrl: './cashback-by-sites-item.component.html',
  styleUrls: ['./cashback-by-sites-item.component.scss']
})
export class CashbackBySitesItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
