import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cashback-by-sites',
  templateUrl: './cashback-by-sites.component.html',
  styleUrls: ['./cashback-by-sites.component.scss']
})
export class CashbackBySitesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
