import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grid-deals',
  templateUrl: './grid-deals.component.html',
  styleUrls: ['./grid-deals.component.scss']
})
export class GridDealsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
