import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grid-deals-item',
  templateUrl: './grid-deals-item.component.html',
  styleUrls: ['./grid-deals-item.component.scss']
})
export class GridDealsItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
