import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-join-social',
  templateUrl: './join-social.component.html',
  styleUrls: ['./join-social.component.scss']
})
export class JoinSocialComponent implements OnInit {
  colorCode = ['#50ca5e59', '#0088cc59', '#3b599859', '#c23b7e59'];
  constructor() {}

  ngOnInit() {}
}
