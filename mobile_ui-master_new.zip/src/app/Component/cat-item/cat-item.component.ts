import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cat-item',
  templateUrl: './cat-item.component.html',
  styleUrls: ['./cat-item.component.scss']
})
export class CatItemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
