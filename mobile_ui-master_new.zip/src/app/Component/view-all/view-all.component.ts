import { Component, OnInit, ViewChild } from "@angular/core";
import { CdkVirtualScrollViewport } from "@angular/cdk/scrolling";
import { Observable, BehaviorSubject } from "rxjs";
import { map, tap, scan, mergeMap, throttleTime } from "rxjs/operators";
import { AngularFirestore } from "@angular/fire/firestore";
import { UtilityService } from "src/app/Services/utility.service";
@Component({
  selector: "app-view-all",
  templateUrl: "./view-all.component.html",
  styleUrls: ["./view-all.component.scss"]
})
export class ViewAllComponent implements OnInit {
  @ViewChild(CdkVirtualScrollViewport, { static: false })
  viewport: CdkVirtualScrollViewport;
  batch = 20;
  theEnd = false;
  offset = new BehaviorSubject(null);
  infinite: Observable<any[]>;
  lastIndex = 0;
  constructor(
    private db: AngularFirestore,
    private utilityService: UtilityService
  ) {
    const batchMap = this.offset.pipe(
      throttleTime(500),
      mergeMap(n => this.getBatch(n)),
      scan((acc, batch) => {
        return { ...acc, ...batch };
      }, {})
    );

    this.infinite = batchMap.pipe(map(v => Object.values(v)));
  }
  getBatch(offset) {
    console.log(offset);
    return this.db
      .collection("peoples", ref =>
        ref
          .orderBy("name")
          .startAfter(offset)
          .limit(this.batch)
      )
      .snapshotChanges()
      .pipe(
        tap(arr => (arr.length ? null : (this.theEnd = true))),
        map(arr => {
          return arr.reduce((acc, cur) => {
            const id = cur.payload.doc.id;
            const data = cur.payload.doc.data();
            return { ...acc, [id]: data };
          }, {});
        })
      );
    console.log(this.infinite);
  }
  ngOnInit() {}
  nextBatch($event, offset) {
    if (this.theEnd) {
      return;
    }

    if (
      this.lastIndex > $event &&
      this.utilityService.isSearchVisible == false
    ) {
      this.utilityService.showSearch();
    } else if (
      this.lastIndex < $event &&
      this.utilityService.isSearchVisible == true
    ) {
      this.utilityService.hideSearch();
    }
    console.log($event);
    const end = this.viewport.getRenderedRange().end;
    const total = this.viewport.getDataLength();
    console.log(`${end}, '>=', ${total}`);
    if (end === total) {
      this.offset.next(offset);
    }
    this.lastIndex = $event;
  }

  trackByIdx(i) {
    return i;
  }
}
