import { Component, OnInit, AfterViewInit } from "@angular/core";
import { UtilityService } from "src/app/Services/utility.service";
import { NavigationEnd, Router, NavigationStart } from "@angular/router";
import { Location } from "@angular/common";

@Component({
  selector: "app-search",
  templateUrl: "./search.component.html",
  styleUrls: ["./search.component.scss"]
})
export class SearchComponent implements AfterViewInit {
  query = "";
  constructor(
    private router: Router,
    private utilityService: UtilityService,
    private _location: Location
  ) {
    this.router.events.subscribe(ev => {
      if (ev instanceof NavigationEnd) {
        this.utilityService.hideSearch(); /* Your code goes here on every router change */
      }
    });
  }

  ngAfterViewInit() {}
  back() {
    this._location.back();
  }
}
