import { Component, OnInit, AfterContentInit } from "@angular/core";
import { UtilityService } from "src/app/Services/utility.service";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"]
})
export class HomeComponent implements OnInit {
  constructor(private utilService: UtilityService) {}

  ngOnInit() {
    this.utilService.showSearch();
  }
  
}
