import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {
  MatInputModule,
  MatButtonModule,
  MatSelectModule,
  MatIconModule,
  MatRippleModule,
  MatToolbarModule,
  MatSidenavModule,
  MatCardModule,
  MatListModule,
  MatDividerModule
} from '@angular/material';
import { FormsModule } from '@angular/forms';
import { SearchComponent } from './Component/search/search.component';
import { HomeComponent } from './Component/home/home.component';
import { SlideshowComponent } from './Component/slideshow/slideshow.component';
import { SlideComponent } from './Component/slide/slide.component';
import { CategoryComponent } from './Component/Categories/category/category.component';
import { HorizontalScrollComponent } from './Shared/horizontal-scroll/horizontal-scroll.component';
import { HorizontalListComponent } from './Component/horizontal-list/horizontal-list.component';
import { CatItemComponent } from './Component/cat-item/cat-item.component';
import { GridDealsComponent } from './Component/grid-deals/grid-deals.component';
import { GridDealsItemComponent } from './Component/grid-deals-item/grid-deals-item.component';

@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    HomeComponent,
    SlideshowComponent,
    SlideComponent,
    CategoryComponent,
    HorizontalScrollComponent,
    HorizontalListComponent,
    CatItemComponent,
    GridDealsComponent,
    GridDealsItemComponent
  ],
  imports: [
    NgbModule.forRoot(),
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatIconModule,
    MatRippleModule,
    MatToolbarModule,
    MatSidenavModule,
    MatCardModule,
    MatListModule,
    MatDividerModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
